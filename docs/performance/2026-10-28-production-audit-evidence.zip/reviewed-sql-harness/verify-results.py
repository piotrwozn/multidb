#!/usr/bin/env python3
"""Independent structural cross-check of the benchmark's raw artifacts."""
import collections
import csv
import json
import math
import pathlib
import sys


def percentile(values, p):
    ordered = sorted(values)
    k = (len(ordered) - 1) * p
    lo, hi = math.floor(k), math.ceil(k)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (k - lo)


def verify(directory):
    path = pathlib.Path(directory)
    results = json.loads((path / 'results.json').read_text())
    failures = json.loads((path / 'failures.json').read_text())
    args = json.loads((path / 'arguments.json').read_text())
    grouped = collections.defaultdict(list)
    with (path / 'latencies.csv').open(newline='') as stream:
        for row in csv.DictReader(stream):
            key = row['engine'], int(row['dataset_rows']), int(row['repeat']), row['workload']
            grouped[key].append(row)
    issues = []
    seen = set()
    for result in results:
        key = result['engine'], result['dataset_rows'], result['repeat'], result['workload']
        if key in seen:
            issues.append(f'duplicate summary: {key}')
        seen.add(key)
        samples = grouped.get(key, [])
        successful = [row for row in samples if row['success'] == 'True']
        errors = len(samples) - len(successful)
        if len(samples) != result['attempts'] or len(successful) != result['successes'] or errors != result['errors']:
            issues.append(f'raw/summary counts differ: {key}')
        if result['elapsed_seconds'] <= 0:
            issues.append(f'nonpositive elapsed time: {key}')
            continue
        if not math.isclose(result['successful_requests_per_second'], len(successful) / result['elapsed_seconds'], rel_tol=1e-9):
            issues.append(f'request throughput mismatch: {key}')
        record_count = sum(int(row['records']) for row in successful)
        if not math.isclose(result['successful_records_per_second'], record_count / result['elapsed_seconds'], rel_tol=1e-9):
            issues.append(f'record throughput mismatch: {key}')
        if successful:
            latencies = [float(row['latency_ms']) for row in successful]
            for name, p in [('p50_ms', .5), ('p95_ms', .95), ('p99_ms', .99)]:
                if not math.isclose(result[name], percentile(latencies, p), rel_tol=1e-9, abs_tol=1e-9):
                    issues.append(f'{name} raw/summary mismatch: {key}')
        if result.get('correctness_status') != 'passed' or errors:
            issues.append(f'run is not valid for comparative conclusions: {key}, status={result.get("correctness_status")}, errors={errors}')
        if result['workload'] == 'load_batch' and not errors and record_count != result['dataset_rows']:
            issues.append(f'loaded record count mismatch: {key}')
    if set(grouped) != seen:
        issues.append('raw CSV contains a key without a corresponding summary')
    workloads = set(args.get('workloads', []))
    if not args.get('only_load'):
        for n in args['rows']:
            for engine in args['engines']:
                expected = {(engine, n, 0, 'load_batch')}
                expected.update((engine, n, rep, work) for rep in range(1, args['repeats'] + 1) for work in workloads)
                for key in sorted(expected - seen):
                    issues.append(f'missing expected summary: {key}')
    if failures:
        issues.append(f'failures.json contains {len(failures)} setup/correctness failures')
    report = {'directory': str(path), 'summaries': len(results), 'raw_samples': sum(map(len, grouped.values())),
              'setup_or_correctness_failures': len(failures), 'issues': issues, 'passed': not issues}
    (path / 'independent-verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    return not issues


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit('usage: verify-results.py RAW_DIRECTORY [RAW_DIRECTORY ...]')
    outcomes = [verify(directory) for directory in sys.argv[1:]]
    raise SystemExit(0 if all(outcomes) else 1)
