# Metodyka rzeczywistego benchmarku

Skrypt `benchmark.py` wysyła rzeczywiste operacje do lokalnych serwerów. Nie korzysta z deklarowanych wyników projektu ani jego smoke-baseline jako substytutu pomiaru. Wyniki dotyczą konkretnego hosta, konfiguracji i wersji zapisanych w artefaktach badania.

## Wspólny zakres

- Serwery na jednej maszynie, loopback TCP, trwałe dane, połączenia utrzymywane między operacjami.
- PostgreSQL i MultiDB: psycopg 3, autocommit, bez automatycznych prepared statements; jawne literały SQL, bez parametrów w `execute`, ten sam simple-query protocol.
- MongoDB: oficjalny PyMongo, natywny protokół; `w=1`, `j=true`, `retryWrites=false`. MongoDB standalone — nie mierzymy wielodokumentowych transakcji wymagających repliki.
- SQL: zwykłe trwałe tabele, `BIGINT`/`TEXT` w PostgreSQL oraz `Int`/`Str` w MultiDB. MongoDB używa jawnych BSON Int64. Identyfikator `id` odpowiada MongoDB `_id`.
- Jeden rekord: identyfikator, kategoria `id % 100`, wartość początkowa równa `id` i deterministyczny tekst 256 znaków. To 256 B samego ASCII payload, nie całego rekordu na dysku.
- Seed `20261028`; domyślnie 10 000 rekordów w tabeli odczytów. Większy wariant 100 000 jest osobnym przebiegiem.
- PostgreSQL: `PRIMARY KEY(id)` i indeks B-tree `category`; MongoDB: domyślny unikalny `_id` i indeks `category`. MultiDB: klucz storage `id` oraz dwa jawne indeksy relacyjne (`id`, `category`), ponieważ ścieżka SQL nie traktuje automatycznie klucza storage jako indeksu dla `WHERE id=...`. Koszt utrzymania tych indeksów jest wliczony w zapis.
- MultiDB ma row-layout, profil transactional. Tabela tworzona przez `/builder/table`, ponieważ ogólne SQL DDL nie jest dostępne. PostgreSQL tworzony przez SQL, MongoDB przez API. Tworzenie schematu nie jest częścią pomiaru CRUD.
- `ANALYZE` wykonywany poza pomiarem w SQL. Rzeczywiste plany zapisują się w `metadata.json`. Dostępność indeksu nie oznacza, że planer używa go w każdym zapytaniu.

## Operacje

| Klucz wyniku | Operacja | Jednostka |
|---|---|---|
| `load_batch` | Załadowanie całego zbioru, paczki domyślnie po 100, indeksy istnieją od początku | żądania/s i rekordy/s; opóźnienie na paczkę |
| `insert_single` | Trwały insert jednego nowego rekordu | żądania/s = rekordy/s |
| `insert_batch` | Insert 100 nowych rekordów | żądania/s i rekordy/s; opóźnienie na paczkę |
| `point_read` | Pełny rekord po istniejącym identyfikatorze | żądania/s |
| `category_read` | Wszystkie rekordy jednej kategorii — 1% zbioru | żądania/s i zwrócone rekordy/s |
| `range_read` | 100 kolejnych identyfikatorów, uporządkowane po id | żądania/s i zwrócone rekordy/s |
| `aggregate` | COUNT i SUM(value), grupowanie na 100 kategorii | zapytania/s; rekordy/s oznaczają wiersze wejściowe |
| `upsert` | Pełne zastąpienie istniejącego rekordu: SQL `INSERT ... ON CONFLICT DO UPDATE` / MongoDB `replace_one(upsert=True)` | żądania/s |
| `mixed_c1` | 80% odczytów punktowych i 20% pełnych upsertów, jeden klient | żądania/s |
| `mixed_c8` | Ten sam mix, osiem klientów | łączne żądania/s |

`upsert` nie jest pomiarem instrukcji SQL `UPDATE`. MultiDB nie udostępnia zwykłego SQL UPDATE w tej ścieżce. Nie emulujemy operacji o innej semantyce i nie oznaczamy jej jako UPDATE.

SQL multi-values INSERT jest atomowy jako jedna instrukcja. W MultiDB potwierdza to ścieżka `execute_insert` → `apply_insert_rows_atomic` → jeden `ConditionalBatch` → `SingleNode::commit_conditional_batch` → jeden backend transaction commit. MongoDB `insert_many(ordered=True)` nie jest atomową transakcją całej paczki. Żądania mają zbliżony cel użytkowy, ale nie identyczne gwarancje atomowości; tego testu nie należy przedstawiać jako porównania kosztu takich samych transakcji ACID.

`range_read` mierzy zapytanie zakresowe z istniejącymi indeksami. MultiDB może skierować je do DataFusion i pełnego skanu; sprawdź plan. Nie nazywamy tego udowodnionym indeksem zakresowym MultiDB.

## Rozgrzewka, powtórzenia i poprawność

- Załadowanie danych i analiza poprzedzają testy odczytu. To głównie test z rozgrzaną pamięcią podręczną, a nie odczyt z zimnego dysku.
- Odczyt punktowy: 25 rozgrzewkowych żądań; kategoria i zakres: 3; agregacja: 2.
- Inserty: 5 pojedynczych rozgrzewkowych zapisów oraz osobna paczka 100 pod rozłącznymi ujemnymi identyfikatorami. Nie pokrywają się z mierzonymi zapisami.
- Upsert: 5 operacji rozgrzewki zapisuje niezmienione wartości; nie zmienia oczekiwanego stanu.
- Mix: osiem trwałych połączeń na silnik jest współdzielonych między c1/c8 i kolejnymi powtórzeniami; przed użyciem wykonywany jest ping, a martwe połączenie jest odtwarzane poza pomiarem. Każde używane połączenie wykonuje do 10 niemierzonych odczytów. Wątki mają rozłączne zbiory kluczy (`id % concurrency`), więc nie występuje konflikt oczekiwanych wartości ani wyścig read-modify-write.
- Załadowanie zbioru (`load_batch`, `repeat=0`) jest mierzone raz na silnik i rozmiar; nie ma dla niego trzech niezależnych powtórzeń. Pozostałe workloady mają domyślnie trzy powtórzenia; kolejność silników rotuje pomiędzy powtórzeniami. Silniki są mierzone kolejno, nigdy jednocześnie. Nie uruchamiaj benchmarku w trakcie kompilacji lub innego ciężkiego procesu.
- Dla każdego odczytu weryfikowane są liczba rekordów i pełne wartości; dla agregacji dokładne count/sum każdej grupy.
- Po load sprawdzana jest pełna agregacja oraz próbki pełnych rekordów. Po upsert sprawdzane są wszystkie zmieniane klucze; po mix ponownie pełna agregacja. Po insert sprawdzane są pełne count/sum całej tabeli zapisów oraz rekordy brzegowe.
- Walidacja odpowiedzi odbywa się poza pomiarem opóźnienia żądania. Przepustowość jest liczona z całkowitego czasu sekcji, który obejmuje narzut pętli, przygotowania operacji i walidacji klienta. W mix mierzony przedział zaczyna się od wspólnego sygnału startu i kończy po ostatniej operacji ostatniego wątku; zamykanie połączeń jest poza nim.
- SQL opóźnienie obejmuje driver, sieć, parsowanie/planning, silnik i odbiór wyniku. Mongo obejmuje natywny driver/protokół. To pomiar end-to-end, a nie izolowanej wydajności storage.
- Niepowodzenia nie trafiają do success throughput ani percentyli sukcesów. Po trzech błędach sekcja kończy się wcześniej. Trzeba podawać odsetek błędów obok throughput.
- W początkowym przebiegu MultiDB odmówił części nowych połączeń: limiter liczy wszystkie próby Startup, także poprawne logowania, z limitem 10 na użytkownika/adres IP w oknie 60 s. Pierwotne wyniki i błędy zachowano w `raw/10k-initial-auth-limit`. Końcowy harness używa trwałej puli; wyłącznie podczas setupu dokładny błąd `authentication rate limit exceeded` powoduje ponawianie co 2 s, maksymalnie przez 75 s. Żadne mierzone operacje danych nie są ponawiane. Odmowy i oczekiwanie zapisują się do `connection-setup-events.jsonl`, poza wynikami wydajności ustalonego połączenia. To ograniczenie zestawiania połączeń pozostaje rzeczywistą cechą badanego serwera.
- Timeout: PG statement_timeout i watchdog klienta; Mongo socketTimeoutMS; watchdog SQL próbuje cancel i zamyka połączenie po przekroczeniu limitu. Domyślnie 15 s na operację. Błąd poprawności lub setup zapisuje się w `failures.json` i daje niezerowy exit code.

## Uruchomienie

Serwery i ich konfigurację uruchamiają dostarczone osobno skrypty. Lokalne testowe poświadczenia są wyłącznie dla jednorazowych danych benchmarkowych.

```bash
cd /workspace/multidb-evaluation
.venv/bin/python benchmark.py --rows 10000 --repeats 3 --output raw/10k
.venv/bin/python benchmark.py --rows 100000 --repeats 3 --output raw/100k
```

Szybki przebieg kontrolny z małą liczbą operacji (nie przedstawiać jako wynik końcowy):

```bash
.venv/bin/python benchmark.py --rows 1000 --repeats 1 --read-ops 20 --write-ops 10 --batch-ops 2 --aggregate-ops 2 --mixed-ops 10 --output raw/smoke
```

Każdy przebieg ma unikalne nazwy tabel. `--run-id` pozwala przypiąć identyfikator, ale ponowne użycie tego samego na istniejących danych nie jest wspierane i ma zakończyć się błędem setup. Skrypt nie usuwa istniejących danych. `--only-load` pozwala zakończyć po utworzeniu i zweryfikowaniu zbioru. `--engines postgres,mongodb,multidb` i `--workloads ...` ograniczają zakres. `--rows` akceptuje listę rozmiarów oddzielonych przecinkami.

## Artefakty

- `arguments.json`: dokładne parametry;
- `latencies.csv`: każde mierzone żądanie, silnik, rozmiar, powtórzenie, workload, wątek, opóźnienie, sukces, liczba rekordów i błąd;
- `results.json`: osobno każdy silnik/rozmiar/powtórzenie/workload; sukcesy, błędy, czas, requests/s, records/s, p50/p95/p99 oraz `correctness_status`. Sekcje oznaczone `failed` należy wykluczyć z porównania wydajności;
- `metadata.json`: rzeczywiste wersje i plany;
- `failures.json`: setup i błędy poprawności.
- `connection-setup-events.jsonl` (jeśli wystąpią zdarzenia): odtwarzanie martwych połączeń i ewentualny backoff uwierzytelniania, wyłącznie poza pomiarem.

Percentyle są interpolowanymi empirycznymi percentylami opóźnień widzianych przez klienta. Przy 10 agregacjach lub 10 paczkach p99 jest praktycznie wartością maksymalną i nie daje wiarygodnego obrazu ogona produkcyjnego. W raporcie dla tych testów trzeba podać liczbę próbek, a p99 traktować wyłącznie opisowo. Trzy powtórzenia pozwalają pokazać zmienność; nie tworzą gwarancji statystycznej przewagi.

## Granice wnioskowania

To mały, jednowęzłowy test na współdzielonej maszynie wirtualnej. 10k/100k rekordów, które mieszczą się w pamięci, nie dowodzi skalowalności, odporności na utratę zasilania, zachowania pod wielogodzinnym obciążeniem, HA ani globalnego ACID. Wektory, pełny tekst, graf, replikacja, sharding, backup/restore i odzyskiwanie po awarii nie są objęte tym harness. Różnice między SQL a natywnym protokołem MongoDB oraz formatami fizycznymi są częścią badanego rozwiązania, a nie wyeliminowaną zmienną.
