#!/usr/bin/env python3
"""Reproducible loopback/database benchmark; all values are generated locally."""
from __future__ import annotations
import argparse, concurrent.futures, csv, datetime, json, math, os, pathlib, random, statistics, threading, time, traceback, urllib.request
from decimal import Decimal
import psycopg
from pymongo import MongoClient
from pymongo.write_concern import WriteConcern
from pymongo.errors import ConnectionFailure
from bson.int64 import Int64

COLUMNS = ('id', 'category', 'value', 'payload')
PASS = 'benchmark-pass-only'  # Local disposable databases only.

def payload(i):
    return f'{i:016x}' * 16

def row(i, value=None):
    return (i, i % 100, i if value is None else value, payload(i))

def sql_values(rows):
    return ','.join(f"({i},{c},{v},'{p}')" for i,c,v,p in rows)

def normal_rows(rows):
    return sorted((int(r[0]), int(r[1]), int(r[2]), str(r[3])) for r in rows)

class SQL:
    def __init__(self, engine, timeout=15):
        self.engine = engine
        self.timeout = timeout
        self.conn = psycopg.connect(host='127.0.0.1', port=15432 if engine == 'postgres' else 15433,
            dbname='bench' if engine == 'postgres' else 'multidb', user='bench' if engine == 'postgres' else 'benchmark',
            password=PASS, connect_timeout=5, autocommit=True, prepare_threshold=None, sslmode='disable')
        if engine == 'postgres':
            self.conn.execute(f'SET statement_timeout={int(timeout*1000)}')
        self.active = None
        self.closed = False
        self.watchdog = threading.Thread(target=self._watch, daemon=True)
        self.watchdog.start()
    def _watch(self):
        while not self.closed:
            time.sleep(.25)
            start = self.active
            if start and time.monotonic()-start > self.timeout:
                try:
                    self.conn.cancel_safe(timeout=2)
                except Exception:
                    pass
                try:
                    self.conn.close()
                except Exception:
                    pass
                return
    def sql(self, sql, fetch=False):
        self.active = time.monotonic()
        try:
            # No parameters and prepare=False: simple-query protocol in both engines.
            cur = self.conn.execute(sql, prepare=False)
            return cur.fetchall() if fetch else cur.rowcount
        finally:
            self.active = None
    def close(self):
        self.closed = True
        self.conn.close()
    def create(self, name):
        if self.engine == 'postgres':
            self.sql(f'CREATE TABLE {name} (id BIGINT PRIMARY KEY, category BIGINT NOT NULL, value BIGINT NOT NULL, payload TEXT NOT NULL)')
            self.sql(f'CREATE INDEX {name}_category ON {name} (category)')
        else:
            body = {'name':name,'schema':{'columns':[{'name':c,'ty':'Str' if c=='payload' else 'Int','nullable':False} for c in COLUMNS],'primary_key':0},
                    'indexes':[{'id':1,'column':0,'expression':{'Column':0},'include':[]}, {'id':2,'column':1,'expression':{'Column':1},'include':[]}]}
            req = urllib.request.Request('http://127.0.0.1:18080/builder/table',data=json.dumps(body).encode(),
                  headers={'Content-Type':'application/json','Authorization':'Bearer benchmark-token-only','X-MultiDB-Principal':'admin'},method='POST')
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req,timeout=20) as response:
                result=json.load(response)
                if not result.get('ok', True):
                    raise RuntimeError(result)
    def insert_prepared(self, name, rows):
        command=f'INSERT INTO {name} (id,category,value,payload) VALUES {sql_values(rows)}'
        return lambda: self.sql(command)
    def upsert_prepared(self, name, r):
        command=f'INSERT INTO {name} (id,category,value,payload) VALUES {sql_values([r])} ON CONFLICT (id) DO UPDATE SET category=EXCLUDED.category,value=EXCLUDED.value,payload=EXCLUDED.payload'
        return lambda: self.sql(command)
    def point(self, name, i):
        return self.sql(f'SELECT id,category,value,payload FROM {name} WHERE id={i}',True)
    def category(self, name, c):
        return self.sql(f'SELECT id,category,value,payload FROM {name} WHERE category={c}',True)
    def range(self, name, start):
        return self.sql(f'SELECT id,category,value,payload FROM {name} WHERE id>={start} AND id<{start+100} ORDER BY id',True)
    def aggregate(self, name):
        result=self.sql(f'SELECT category,COUNT(*),SUM(value) FROM {name} GROUP BY category ORDER BY category',True)
        return sorted((int(c),int(n),int(v)) for c,n,v in result)
    def analyze(self,name):
        self.sql(f'ANALYZE {name}')
    def explain(self,name):
        result={}
        for key,query in [('point',f'SELECT id,category,value,payload FROM {name} WHERE id=42'),('category',f'SELECT id,category,value,payload FROM {name} WHERE category=42'),('range',f'SELECT id,category,value,payload FROM {name} WHERE id>=42 AND id<142 ORDER BY id'),('aggregate',f'SELECT category,COUNT(*),SUM(value) FROM {name} GROUP BY category ORDER BY category')]:
            try: result[key]=self.sql('EXPLAIN '+query,True)
            except Exception as error: result[key]={'error':str(error)}
        return result
    def version(self):
        return self.sql('SELECT version()',True)

class Mongo:
    def __init__(self,engine='mongodb',timeout=15):
        self.engine='mongodb'
        self.client=MongoClient('mongodb://benchmark:'+PASS+'@127.0.0.1:27018/?authSource=admin',
            serverSelectionTimeoutMS=5000,socketTimeoutMS=int(timeout*1000),connectTimeoutMS=5000,
            retryWrites=False,maxPoolSize=1)
        self.db=self.client.get_database('bench',write_concern=WriteConcern(w=1,j=True))
        self.client.admin.command('ping')
    def close(self): self.client.close()
    def create(self,name):
        self.db.create_collection(name)
        self.db[name].create_index('category')
    @staticmethod
    def document(r):
        return {'_id':Int64(r[0]),'category':Int64(r[1]),'value':Int64(r[2]),'payload':r[3]}
    @staticmethod
    def rows(docs):
        return [(int(d['_id']),int(d['category']),int(d['value']),d['payload']) for d in docs]
    def insert_prepared(self,name,rows):
        docs=[self.document(r) for r in rows]
        if len(docs)==1:
            return lambda: self.db[name].insert_one(docs[0])
        return lambda: self.db[name].insert_many(docs,ordered=True)
    def upsert_prepared(self,name,r):
        doc=self.document(r)
        return lambda: self.db[name].replace_one({'_id':doc['_id']},doc,upsert=True)
    def point(self,name,i):
        doc=self.db[name].find_one({'_id':i})
        return self.rows([doc]) if doc else []
    def category(self,name,c): return self.rows(list(self.db[name].find({'category':c})))
    def range(self,name,start): return self.rows(list(self.db[name].find({'_id':{'$gte':start,'$lt':start+100}}).sort('_id',1)))
    def aggregate(self,name):
        docs=list(self.db[name].aggregate([{'$group':{'_id':'$category','n':{'$sum':1},'total':{'$sum':'$value'}}},{'$sort':{'_id':1}}]))
        return [(int(d['_id']),int(d['n']),int(d['total'])) for d in docs]
    def analyze(self,name): pass
    def explain(self,name):
        return {'point':self.db[name].find({'_id':42}).explain(),'category':self.db[name].find({'category':42}).explain(),
                'range':self.db[name].find({'_id':{'$gte':42,'$lt':142}}).sort('_id',1).explain()}
    def version(self): return self.client.server_info()

def adapter(engine,timeout=15): return Mongo(timeout=timeout) if engine=='mongodb' else SQL(engine,timeout)

def connection_setup_event(path,engine,event,**details):
    entry={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'engine':engine,'event':event,**details}
    with open(path/'connection-setup-events.jsonl','a') as file:file.write(json.dumps(entry,default=str)+'\n')

def connect_for_setup(engine,timeout,event_path):
    """Only startup/authentication is retried, never a measured data operation."""
    deadline=time.monotonic()+75
    attempts=0
    while True:
        attempts+=1
        try:
            connection=adapter(engine,timeout)
            if attempts>1:connection_setup_event(event_path,engine,'connected_after_auth_backoff',attempts=attempts)
            return connection
        except Exception as error:
            if engine!='multidb' or 'authentication rate limit exceeded' not in str(error):raise
            remaining=deadline-time.monotonic()
            if remaining<=0:raise
            connection_setup_event(event_path,engine,'auth_rate_backoff_outside_timing',attempt=attempts,error=str(error),sleep_seconds=min(2,remaining))
            if attempts==1 or attempts%5==0:
                print(json.dumps({'connection_setup':engine,'status':'authentication rate limit; waiting outside timing','attempt':attempts}),flush=True)
            time.sleep(min(2,remaining))

def ensure_live(connection,engine,timeout,event_path):
    """Ping before use; replace only a dead/closed connection, outside measurement."""
    try:
        if engine=='mongodb':connection.client.admin.command('ping')
        else:connection.sql('SELECT version()',True)
        return connection
    except (psycopg.OperationalError,psycopg.InterfaceError,ConnectionFailure) as error:
        connection_setup_event(event_path,engine,'refresh_dead_connection_outside_timing',error=str(error))
        try:connection.close()
        except Exception:pass
        return connect_for_setup(engine,timeout,event_path)

class WorkerPool:
    """Persistent per-engine clients reused by c1/c8 and all repetitions."""
    def __init__(self,engine,timeout,event_path):
        self.engine=engine;self.timeout=timeout;self.event_path=event_path;self.connections=[]
    def get(self,count):
        while len(self.connections)<count:
            self.connections.append(connect_for_setup(self.engine,self.timeout,self.event_path))
        # Creation/backoff may leave an earlier client idle long enough to expire.
        for i in range(count):
            self.connections[i]=ensure_live(self.connections[i],self.engine,self.timeout,self.event_path)
        return self.connections[:count]
    def close(self):
        for connection in self.connections:
            try:connection.close()
            except Exception:pass

def percentile(values,p):
    if not values: return None
    a=sorted(values); k=(len(a)-1)*p; lo=math.floor(k); hi=math.ceil(k)
    return a[lo]+(a[hi]-a[lo])*(k-lo)

class Recorder:
    def __init__(self,path):
        self.path=path; self.lock=threading.Lock(); self.summaries=[]; self.samples=[]
        self.file=open(path/'latencies.csv','w',newline=''); self.writer=csv.DictWriter(self.file,fieldnames=['engine','dataset_rows','repeat','workload','worker','operation','latency_ms','success','records','error'])
        self.writer.writeheader(); self.file.flush()
    def summary(self,engine,n,rep,name,samples,elapsed,notes=''):
        successful=[s for s in samples if s['success']]
        lat=[s['latency_ms'] for s in successful]
        result={'engine':engine,'dataset_rows':n,'repeat':rep,'workload':name,'elapsed_seconds':elapsed,
            'attempts':len(samples),'successes':len(successful),'errors':len(samples)-len(successful),
            'successful_requests_per_second':len(successful)/elapsed if elapsed else 0,
            'successful_records_per_second':sum(s['records'] for s in successful)/elapsed if elapsed else 0,
            'p50_ms':percentile(lat,.5),'p95_ms':percentile(lat,.95),'p99_ms':percentile(lat,.99),'notes':notes,'correctness_status':'passed' if not any(not s['success'] for s in samples) else 'operation_errors'}
        with self.lock:
            for sample in samples:
                self.writer.writerow({'engine':engine,'dataset_rows':n,'repeat':rep,'workload':name,**sample})
            self.file.flush(); self.summaries.append(result)
            with open(self.path/'results.json','w') as f:json.dump(self.summaries,f,indent=2,default=str)
        print(json.dumps(result,default=str),flush=True)
        return result

    def invalidate(self,engine,n,rep,name,error):
        for result in reversed(self.summaries):
            if (result['engine'],result['dataset_rows'],result['repeat'],result['workload'])==(engine,n,rep,name):
                result['correctness_status']='failed';result['correctness_error']=str(error);break
        with open(self.path/'results.json','w') as f:json.dump(self.summaries,f,indent=2,default=str)

    def run(self,engine,n,rep,name,count,make_op,check=lambda result,index:None,records=1,warmup=0,notes=''):
        for i in range(warmup):
            op=make_op(-i-1); result=op(); check(result,-i-1)
        samples=[]; errors=0; start=time.perf_counter()
        for i in range(count):
            op=make_op(i); t=time.perf_counter(); error=''; okay=True
            try:
                value=op(); elapsed=(time.perf_counter()-t)*1000
                check(value,i)
            except Exception as exc:
                elapsed=(time.perf_counter()-t)*1000; okay=False;error=f'{type(exc).__name__}: {exc}'
            samples.append({'worker':0,'operation':i,'latency_ms':elapsed,'success':okay,'records':(records(i) if callable(records) else records) if okay else 0,'error':error})
            if not okay:errors+=1
            if errors>=3: break
        return self.summary(engine,n,rep,name,samples,time.perf_counter()-start,notes)


def assert_rows(actual,expected):
    normalized=normal_rows(actual)
    if normalized!=sorted(expected):
        raise AssertionError(f'Rows differ: actual_count={len(normalized)}, expected_count={len(expected)}, actual_head={normalized[:2]}, expected_head={sorted(expected)[:2]}')

def agg_expected(expected):
    return [(c,sum(1 for i in expected if i%100==c),sum(v for i,v in expected.items() if i%100==c)) for c in range(100) if any(i%100==c for i in expected)]

def mixed(rec,engine,n,rep,name,table,expected,args,workers,worker_pool):
    connections=worker_pool.get(workers)  # connect, healthcheck and rate backoff are outside timing
    barrier=threading.Barrier(workers+1); start_event=threading.Event(); samples=[]; finished=[]; lock=threading.Lock()
    def worker(w):
        connection=connections[w]; local=[];errors=0
        rng=random.Random(args.seed+rep*1000+w); ids=list(range(w,n,workers))
        # Warm the established connection, no writes and no sample counted.
        for i in ids[:min(10,len(ids))]:assert_rows(connection.point(table,i),[row(i,expected[i])])
        barrier.wait()
        start_event.wait()
        try:
            for index in range(args.mixed_ops):
                i=rng.choice(ids); write=(index%5==0)
                value=1_000_000_000+rep*10_000_000+w*100_000+index
                op=connection.upsert_prepared(table,row(i,value)) if write else lambda i=i: connection.point(table,i)
                t=time.perf_counter();okay=True;error=''
                try:
                    result=op();lat=(time.perf_counter()-t)*1000
                    if write: expected[i]=value
                    else: assert_rows(result,[row(i,expected[i])])
                except Exception as exc:
                    lat=(time.perf_counter()-t)*1000;okay=False;error=f'{type(exc).__name__}: {exc}'
                local.append({'worker':w,'operation':index,'latency_ms':lat,'success':okay,'records':1 if okay else 0,'error':error})
                if not okay:errors+=1
                if errors>=3: break
        finally:
            completed=time.perf_counter()
            with lock:
                samples.extend(local);finished.append(completed)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(worker,w) for w in range(workers)]
        # Abort barrier on connect failures rather than wait indefinitely.
        try:barrier.wait(timeout=30)
        except threading.BrokenBarrierError:
            for f in futures:
                if f.done(): f.result()
            raise
        start=time.perf_counter();start_event.set()
        for f in futures:f.result()
    rec.summary(engine,n,rep,name,samples,max(finished)-start,notes='80% point reads / 20% full-row replacement upserts; disjoint keys per worker; concurrency='+str(workers))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--engines',default='postgres,mongodb,multidb');p.add_argument('--rows',default='10000')
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--read-ops',type=int,default=500)
    p.add_argument('--write-ops',type=int,default=200);p.add_argument('--batch-ops',type=int,default=10)
    p.add_argument('--aggregate-ops',type=int,default=10);p.add_argument('--mixed-ops',type=int,default=100)
    p.add_argument('--batch-size',type=int,default=100);p.add_argument('--timeout',type=float,default=15)
    p.add_argument('--seed',type=int,default=20261028);p.add_argument('--run-id',default=datetime.datetime.now(datetime.timezone.utc).strftime('%m%d%H%M%S'))
    p.add_argument('--output',default='raw/run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    p.add_argument('--workloads',default='insert_single,insert_batch,point_read,category_read,range_read,aggregate,upsert,mixed_c1,mixed_c8')
    p.add_argument('--only-load',action='store_true');args=p.parse_args()
    args.engines=args.engines.split(',');args.rows=[int(x) for x in args.rows.split(',')];args.workloads=set(args.workloads.split(','))
    if any(n<100 for n in args.rows):p.error('--rows must be >=100')
    if not set(args.engines)<= {'postgres','mongodb','multidb'}:p.error('unknown engine')
    if min(args.repeats,args.read_ops,args.write_ops,args.batch_ops,args.aggregate_ops,args.mixed_ops,args.batch_size)<1:p.error('operation counts and repeats must be >=1')
    output=pathlib.Path(args.output);output.mkdir(parents=True,exist_ok=True)
    with open(output/'arguments.json','w') as f:json.dump(vars(args),f,indent=2,default=list)
    rec=Recorder(output);contexts={};metadata={};failures=[]
    worker_pools={engine:WorkerPool(engine,args.timeout,output) for engine in args.engines}
    for n in args.rows:
        for engine in args.engines:
            key=(n,engine)
            try:
                connection=connect_for_setup(engine,args.timeout,output)
                table=f'bread_{args.run_id}_{n}';write_table=f'bwrite_{args.run_id}_{n}'
                connection.create(table);connection.create(write_table)
                metadata.setdefault(engine,{'version':connection.version()})
                rows=[row(i) for i in range(n)]
                batches=[rows[i:i+args.batch_size] for i in range(0,n,args.batch_size)]
                def load_op(i):return connection.insert_prepared(table,batches[i])
                result=rec.run(engine,n,0,'load_batch',len(batches),load_op,records=lambda i:len(batches[i]),notes='Existing primary and category indexes; timed durable batches; statements built outside individual latency.')
                if result['errors']:raise RuntimeError('load failed; timing that depends on dataset is refused')
                expected={i:i for i in range(n)}
                actual=connection.aggregate(table)
                if actual!=agg_expected(expected):raise AssertionError(f'Aggregate mismatch after load {actual[:2]}')
                for i in [0,42,n//2,n-1]:assert_rows(connection.point(table,i),[row(i)])
                connection.analyze(table)
                metadata[engine][f'plans_{n}']=connection.explain(table)
                contexts[key]=(connection,table,write_table,expected,{})
            except Exception as error:
                rec.invalidate(engine,n,0,'load_batch',error)
                failures.append({'engine':engine,'rows':n,'stage':'setup','error':str(error),'traceback':traceback.format_exc()});print(json.dumps(failures[-1]),flush=True)
        if args.only_load:continue
        for rep in range(1,args.repeats+1):
            # Rotate order to reduce systematic time/host drift.
            order=args.engines[(rep-1)%len(args.engines):]+args.engines[:(rep-1)%len(args.engines)]
            for engine in order:
                if (n,engine) not in contexts:continue
                connection,table,write_table,expected,write_expected=contexts[(n,engine)]
                rng=random.Random(args.seed+rep)
                for name in ['point_read','category_read','range_read','aggregate','insert_single','insert_batch','upsert','mixed_c1','mixed_c8']:
                    if name not in args.workloads:continue
                    try:
                        connection=ensure_live(connection,engine,args.timeout,output)
                        contexts[(n,engine)]=(connection,table,write_table,expected,write_expected)
                        ids=[rng.randrange(n) for _ in range(args.read_ops+100)]
                        if name=='point_read':
                            rec.run(engine,n,rep,name,args.read_ops,lambda j:lambda:connection.point(table,ids[j]),lambda result,j:assert_rows(result,[row(ids[j],expected[ids[j]])]),warmup=25)
                        elif name=='category_read':
                            cats=[i%100 for i in ids];gold={c:[row(i,expected[i]) for i in range(c,n,100)] for c in set(cats)}
                            rec.run(engine,n,rep,name,max(20,args.read_ops//10),lambda j:lambda:connection.category(table,cats[j]),lambda result,j:assert_rows(result,gold[cats[j]]),records=n//100,warmup=3)
                        elif name=='range_read':
                            starts=[min(i,n-100) for i in ids]
                            rec.run(engine,n,rep,name,max(20,args.read_ops//10),lambda j:lambda:connection.range(table,starts[j]),lambda result,j:assert_rows(result,[row(i,expected[i]) for i in range(starts[j],starts[j]+100)]),records=100,warmup=3,notes='100 consecutive IDs ordered; physical access path recorded in plans; MultiDB may full-scan.')
                        elif name=='aggregate':
                            gold=agg_expected(expected)
                            def check(result,j):
                                if result!=gold:raise AssertionError(f'Aggregate mismatch {result[:2]} vs {gold[:2]}')
                            rec.run(engine,n,rep,name,args.aggregate_ops,lambda j:lambda:connection.aggregate(table),check,records=n,warmup=2,notes='COUNT and SUM(value) grouped into 100 categories; records/sec denotes input rows.')
                        elif name=='insert_single':
                            offset=rep*10_000_000
                            for j in range(5):
                                connection.insert_prepared(write_table,[row(-offset-j-1)])();write_expected[-offset-j-1]=-offset-j-1
                            prepared=[connection.insert_prepared(write_table,[row(offset+i)]) for i in range(args.write_ops)]
                            rec.run(engine,n,rep,name,args.write_ops,lambda j:prepared[j],lambda result,j:write_expected.update({offset+j:offset+j}))
                            if connection.aggregate(write_table)!=agg_expected(write_expected):raise AssertionError('Write-table aggregate mismatch after insert_single')
                            for i in [0,args.write_ops-1]:assert_rows(connection.point(write_table,offset+i),[row(offset+i)])
                        elif name=='insert_batch':
                            offset=rep*10_000_000+1_000_000
                            connection.insert_prepared(write_table,[row(-offset-i-1) for i in range(args.batch_size)])()
                            write_expected.update({-offset-i-1:-offset-i-1 for i in range(args.batch_size)})
                            prepared=[connection.insert_prepared(write_table,[row(offset+j*args.batch_size+i) for i in range(args.batch_size)]) for j in range(args.batch_ops)]
                            rec.run(engine,n,rep,name,args.batch_ops,lambda j:prepared[j],lambda result,j:write_expected.update({offset+j*args.batch_size+i:offset+j*args.batch_size+i for i in range(args.batch_size)}),records=args.batch_size,notes='100 rows/request by default; SQL multi-values INSERT atomic, Mongo ordered insert_many is not an atomic multi-document transaction.')
                            if connection.aggregate(write_table)!=agg_expected(write_expected):raise AssertionError('Write-table aggregate mismatch after insert_batch')
                            for i in [0,args.batch_ops*args.batch_size-1]:assert_rows(connection.point(write_table,offset+i),[row(offset+i)])
                        elif name=='upsert':
                            chosen=[i%n for i in range(args.write_ops)];values=[2_000_000_000+rep*1_000_000+j for j in range(args.write_ops)]
                            for i in chosen[:5]:connection.upsert_prepared(table,row(i,expected[i]))()
                            prepared=[connection.upsert_prepared(table,row(i,v)) for i,v in zip(chosen,values)]
                            def update_expected(result,j):expected[chosen[j]]=values[j]
                            rec.run(engine,n,rep,name,args.write_ops,lambda j:prepared[j],update_expected,notes='Existing-key full-row replacement via SQL INSERT ON CONFLICT / Mongo replace_one(upsert=True); not a SQL UPDATE benchmark.')
                            for i in sorted(set(chosen)):assert_rows(connection.point(table,i),[row(i,expected[i])])
                        else:
                            mixed(rec,engine,n,rep,name,table,expected,args,1 if name=='mixed_c1' else 8,worker_pools[engine])
                            connection=ensure_live(connection,engine,args.timeout,output)
                            contexts[(n,engine)]=(connection,table,write_table,expected,write_expected)
                            if connection.aggregate(table)!=agg_expected(expected):raise AssertionError('Full post-mixed aggregate mismatch')
                    except Exception as error:
                        rec.invalidate(engine,n,rep,name,error)
                        failures.append({'engine':engine,'rows':n,'repeat':rep,'workload':name,'error':str(error),'traceback':traceback.format_exc()});print(json.dumps(failures[-1]),flush=True)
    for connection,*_ in contexts.values():
        try:connection.close()
        except Exception:pass
    for worker_pool in worker_pools.values():worker_pool.close()
    with open(output/'metadata.json','w') as f:json.dump(metadata,f,indent=2,default=str)
    with open(output/'failures.json','w') as f:json.dump(failures,f,indent=2,default=str)
    rec.file.close()
    print(json.dumps({'output':str(output),'summaries':len(rec.summaries),'setup_or_correctness_failures':len(failures),'operation_errors':sum(r['errors'] for r in rec.summaries)}),flush=True)
    return 1 if failures or any(r['errors'] for r in rec.summaries) else 0

if __name__=='__main__':raise SystemExit(main())
