#!/usr/bin/env python3
"""Grant the benchmark SCRAM user access through the documented admin API."""
import json
import time
import urllib.request

BASE = "http://127.0.0.1:18080"
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
HEADERS = {
    "Authorization": "Bearer benchmark-token-only",
    "Content-Type": "application/json",
    "X-MultiDB-Principal": "admin",
}

for attempt in range(60):
    try:
        with opener.open(BASE + "/health", timeout=2) as response:
            if response.status == 200:
                break
    except Exception:
        time.sleep(1)
else:
    raise SystemExit("MultiDB did not become healthy within 60 seconds")

request = urllib.request.Request(BASE + "/security", headers=HEADERS)
with opener.open(request, timeout=10) as response:
    security = json.load(response)["data"]
principals = [entry for entry in security["principals"] if entry["user"] != "benchmark"]
principals.append({"user": "benchmark", "principal": "benchmark", "roles": ["admin"]})
payload = {"roles": security["roles"], "principals": principals}
request = urllib.request.Request(
    BASE + "/security", data=json.dumps(payload).encode(), headers=HEADERS, method="POST"
)
with opener.open(request, timeout=10) as response:
    result = json.load(response)
    assert result["ok"] is True, result
print(json.dumps({"health": "ok", "benchmark_principal": "admin"}))
