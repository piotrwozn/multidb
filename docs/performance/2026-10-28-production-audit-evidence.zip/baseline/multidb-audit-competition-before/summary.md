# Pinned competitor measurements

Median across independent repetitions of each section; first operations may be cold unless the adapter explicitly warms them. Throughput includes client validation. Raw samples retain every attempted request.

These are end-to-end API/deployment comparisons. Protocols, audit, durability APIs and resource limits differ where recorded in run.json and domain metadata. No physical GPU or universal ranking is claimed.

| Domain | Workload | Rows/vectors | Engine | Repeats | Samples | Requests/s | p50 ms | p95 ms | p99 ms | p99 repeat range ms |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|---|
| sql | aggregate | 10000 | mongodb | 3 | 90 | 324.45 | 3.0563 | 3.2905 | 3.4340 | 3.3936–4.3612 |
| sql | aggregate | 10000 | multidb | 3 | 90 | 444.56 | 2.2369 | 2.4759 | 2.5319 | 2.4009–4.4026 |
| sql | aggregate | 10000 | postgres | 3 | 90 | 645.61 | 1.5359 | 1.6611 | 1.6677 | 1.6328–1.9890 |
| sql | aggregate | 100000 | mongodb | 3 | 90 | 31.52 | 31.4754 | 33.2773 | 33.4461 | 32.6031–34.5007 |
| sql | aggregate | 100000 | multidb | 3 | 90 | 327.17 | 3.0283 | 3.4918 | 3.7693 | 3.5298–4.7422 |
| sql | aggregate | 100000 | postgres | 3 | 90 | 72.45 | 13.7147 | 14.8118 | 14.9977 | 14.7783–15.8708 |
| sql | category_read | 10000 | mongodb | 3 | 300 | 1574.57 | 0.5965 | 0.6772 | 0.7378 | 0.6789–0.7444 |
| sql | category_read | 10000 | multidb | 3 | 300 | 651.95 | 1.4742 | 1.7432 | 1.9063 | 1.5025–2.5169 |
| sql | category_read | 10000 | postgres | 3 | 300 | 4401.81 | 0.1958 | 0.2778 | 0.3002 | 0.2974–1.2486 |
| sql | category_read | 100000 | mongodb | 3 | 300 | 279.53 | 3.0403 | 3.6953 | 5.3194 | 3.7051–5.3329 |
| sql | category_read | 100000 | multidb | 3 | 300 | 216.33 | 4.2424 | 5.0908 | 5.5041 | 4.5574–5.7195 |
| sql | category_read | 100000 | postgres | 3 | 300 | 602.04 | 1.3742 | 1.6093 | 1.8334 | 1.6705–1.8679 |
| sql | insert_batch | 10000 | mongodb | 3 | 90 | 897.38 | 1.0633 | 1.2839 | 1.3621 | 1.1299–3.2865 |
| sql | insert_batch | 10000 | multidb | 3 | 90 | 91.23 | 10.9521 | 12.9715 | 13.3018 | 12.7742–14.4857 |
| sql | insert_batch | 10000 | postgres | 3 | 90 | 920.28 | 1.0163 | 1.1910 | 1.1988 | 1.1068–1.3505 |
| sql | insert_batch | 100000 | mongodb | 3 | 90 | 867.39 | 1.0897 | 1.2364 | 1.3788 | 1.2418–1.8921 |
| sql | insert_batch | 100000 | multidb | 3 | 90 | 94.71 | 10.2409 | 13.2939 | 15.4825 | 15.3354–15.7765 |
| sql | insert_batch | 100000 | postgres | 3 | 90 | 958.92 | 1.0075 | 1.1832 | 1.3004 | 1.2446–1.3068 |
| sql | insert_single | 10000 | mongodb | 3 | 900 | 2290.23 | 0.4229 | 0.5441 | 0.8562 | 0.6867–0.9173 |
| sql | insert_single | 10000 | multidb | 3 | 900 | 560.89 | 1.7298 | 2.2452 | 3.0103 | 2.7590–3.6784 |
| sql | insert_single | 10000 | postgres | 3 | 900 | 3224.58 | 0.2833 | 0.4560 | 0.6505 | 0.4939–0.7462 |
| sql | insert_single | 100000 | mongodb | 3 | 900 | 1917.31 | 0.4913 | 0.6488 | 0.8614 | 0.7032–0.9686 |
| sql | insert_single | 100000 | multidb | 3 | 900 | 503.14 | 1.9599 | 2.3477 | 3.0985 | 2.8843–4.0530 |
| sql | insert_single | 100000 | postgres | 3 | 900 | 3313.20 | 0.2864 | 0.4256 | 0.6277 | 0.4495–0.6579 |
| sql | load_batch | 10000 | mongodb | 1 | 100 | 828.00 | 1.1164 | 1.3641 | 1.6445 | 1.6445–1.6445 |
| sql | load_batch | 10000 | multidb | 1 | 100 | 106.67 | 9.4296 | 10.6522 | 11.6082 | 11.6082–11.6082 |
| sql | load_batch | 10000 | postgres | 1 | 100 | 747.07 | 1.1588 | 1.4319 | 4.1637 | 4.1637–4.1637 |
| sql | load_batch | 100000 | mongodb | 1 | 1000 | 804.03 | 1.1215 | 1.4259 | 2.7781 | 2.7781–2.7781 |
| sql | load_batch | 100000 | multidb | 1 | 1000 | 80.46 | 12.4827 | 13.8381 | 16.5547 | 16.5547–16.5547 |
| sql | load_batch | 100000 | postgres | 1 | 1000 | 805.72 | 1.1333 | 1.3842 | 1.9030 | 1.9030–1.9030 |
| sql | mixed_c1 | 10000 | mongodb | 3 | 1500 | 3332.98 | 0.2370 | 0.5942 | 0.6988 | 0.6261–0.8053 |
| sql | mixed_c1 | 10000 | multidb | 3 | 1500 | 853.16 | 1.0638 | 1.6816 | 2.0204 | 1.9059–2.3690 |
| sql | mixed_c1 | 10000 | postgres | 3 | 1500 | 5705.94 | 0.1118 | 0.4360 | 0.5152 | 0.5049–0.5630 |
| sql | mixed_c1 | 100000 | mongodb | 3 | 1500 | 3091.89 | 0.2494 | 0.6274 | 0.7069 | 0.7053–0.9505 |
| sql | mixed_c1 | 100000 | multidb | 3 | 1500 | 782.96 | 1.1198 | 1.8489 | 2.6237 | 2.0809–3.3526 |
| sql | mixed_c1 | 100000 | postgres | 3 | 1500 | 5094.17 | 0.1433 | 0.4085 | 0.4761 | 0.4254–0.5773 |
| sql | mixed_c8 | 10000 | mongodb | 3 | 12000 | 7719.37 | 0.8169 | 2.1863 | 3.5336 | 3.1945–3.8699 |
| sql | mixed_c8 | 10000 | multidb | 3 | 12000 | 2256.59 | 2.8713 | 7.2309 | 9.1555 | 9.0531–9.2885 |
| sql | mixed_c8 | 10000 | postgres | 3 | 12000 | 18271.86 | 0.3084 | 1.0238 | 1.4504 | 1.3346–2.4442 |
| sql | mixed_c8 | 100000 | mongodb | 3 | 12000 | 7712.79 | 0.8247 | 2.3649 | 3.7932 | 3.1856–4.3821 |
| sql | mixed_c8 | 100000 | multidb | 3 | 12000 | 2161.75 | 3.0776 | 7.2883 | 9.5642 | 9.1895–10.1255 |
| sql | mixed_c8 | 100000 | postgres | 3 | 12000 | 16656.54 | 0.3514 | 1.1906 | 1.6095 | 1.4252–1.7823 |
| sql | point_read | 10000 | mongodb | 3 | 3000 | 4809.29 | 0.1830 | 0.2618 | 0.3520 | 0.3206–0.3719 |
| sql | point_read | 10000 | multidb | 3 | 3000 | 987.66 | 0.9839 | 1.2234 | 1.6554 | 1.6544–1.7347 |
| sql | point_read | 10000 | postgres | 3 | 3000 | 9102.50 | 0.0989 | 0.1471 | 0.2060 | 0.1860–0.2216 |
| sql | point_read | 100000 | mongodb | 3 | 3000 | 4983.71 | 0.1819 | 0.2563 | 0.3559 | 0.2804–0.4362 |
| sql | point_read | 100000 | multidb | 3 | 3000 | 855.98 | 1.1431 | 1.3736 | 1.8291 | 1.5307–2.5663 |
| sql | point_read | 100000 | postgres | 3 | 3000 | 7671.30 | 0.1088 | 0.1623 | 0.1980 | 0.1453–0.5644 |
| sql | range_read | 10000 | mongodb | 3 | 300 | 1491.91 | 0.5910 | 0.6719 | 0.7255 | 0.6675–0.8174 |
| sql | range_read | 10000 | multidb | 3 | 300 | 733.38 | 1.2681 | 1.6132 | 2.0255 | 1.7789–2.0708 |
| sql | range_read | 10000 | postgres | 3 | 300 | 4304.78 | 0.1720 | 0.2386 | 0.3825 | 0.2706–0.6034 |
| sql | range_read | 100000 | mongodb | 3 | 300 | 1712.81 | 0.5197 | 0.5942 | 0.7213 | 0.5994–0.7332 |
| sql | range_read | 100000 | multidb | 3 | 300 | 695.99 | 1.3682 | 1.5920 | 1.6366 | 1.5095–2.3649 |
| sql | range_read | 100000 | postgres | 3 | 300 | 3387.62 | 0.2077 | 0.2449 | 0.2809 | 0.2731–0.6336 |
| sql | upsert | 10000 | mongodb | 3 | 900 | 1759.01 | 0.5496 | 0.7233 | 0.9332 | 0.9266–1.1300 |
| sql | upsert | 10000 | multidb | 3 | 900 | 675.93 | 1.4297 | 1.9005 | 2.5400 | 2.2197–2.5609 |
| sql | upsert | 10000 | postgres | 3 | 900 | 2715.82 | 0.3389 | 0.4828 | 0.6598 | 0.5563–1.1942 |
| sql | upsert | 100000 | mongodb | 3 | 900 | 1891.91 | 0.4971 | 0.6845 | 1.0405 | 0.8069–1.4389 |
| sql | upsert | 100000 | multidb | 3 | 900 | 577.90 | 1.6495 | 2.0341 | 3.7522 | 2.4131–4.5096 |
| sql | upsert | 100000 | postgres | 3 | 900 | 3025.53 | 0.3051 | 0.4287 | 0.5552 | 0.5190–0.5836 |

Percentiles with fewer than100 successful samples are descriptive small-sample observations. Load sections may contain only one repetition; they must not be described as three-repeat load trials.
