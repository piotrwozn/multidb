MultiDB production audit evidence, 2026-10-28

accepted/ contains the six qualified domains (378 sections / 156030 timed
requests / 130 aggregate cells). baseline/ is the PR #38 SQL reference only.
paired-optimization/ is the separate matched 1000-sample CPU tensor diagnostic.
excluded-attempts/ retains metadata, failures, logs and proofs of invalid or
calibration attempts; these never enter the final ranking. Discarded disposable
database/binary files have cleanup provenance where available.

No executables, database files, container volumes, actual tensor datasets,
virtual environments or credentials from the execution environment are bundled.
Literal service passwords appearing in reviewed benchmark commands are public,
disposable fixture constants, not deployment secrets. Binary checksums and Git
commits identify the artifacts. This archive is evidence, not an install image.

MANIFEST.json hashes every other member. Verify the archive SHA-256 against the
companion file, then verify the manifest. LAUNCH-TOOLING.json maps each launch's
recorded Python file hash to a content-addressed source file. The vector launch
used a composed driver tree (calibrated ef=1024 plus then-current runner/report),
which is recorded honestly rather than attributed wholly to the engine commit.

Run from the extracted root, with pinned optional dependencies installed:
python report-tooling/scripts/benchmarks/report_competition.py \
  accepted/multidb-audit-qualified2-sql \
  accepted/multidb-audit-qualified2-analytics \
  accepted/multidb-audit-qualified2-kv \
  accepted/multidb-audit-qualified2-graph \
  accepted/multidb-audit-qualified2-tensor \
  accepted/multidb-audit-vector-quality \
  --require-full-suite --output-prefix regenerated

Original metadata includes original workspace paths; they are provenance, not
required extraction destinations. The reviewed SQL harness can independently
reverify the included SQL CSV/results. Raw timing records are not independent
fresh database loads. Full limits and production acceptance gates are in reports/.
